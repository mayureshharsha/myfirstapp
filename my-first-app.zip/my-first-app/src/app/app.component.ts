import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private http: HttpClient) {
  }
  title = 'my-first-app';

  userName: String = "";

  response: any;

  fetchUserdetails() {
    let obs = this.http.get('https://api.github.com/users/' + this.userName);
    obs.subscribe(
      (response) => {
        this.response = response;
        console.log(response)
      }
    )
  }
}
